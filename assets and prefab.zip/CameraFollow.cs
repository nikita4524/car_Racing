using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Target Settings")]
    [SerializeField] private Transform player;         // Player car to follow
    [SerializeField] private Vector3 offset = new Vector3(0f, 5f, -10f); // Camera offset

    [Header("Smooth Settings")]
    [SerializeField] private float smoothSpeed = 5f;   // Smoothness of camera movement

    void LateUpdate()
    {
        if (player == null) return;

        Vector3 desiredPosition = player.position + offset;
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);
        transform.position = smoothedPosition;
    }
}