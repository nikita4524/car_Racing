﻿using UnityEngine;

public class CarController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float forwardSpeed = 10f;
    public float laneWidth = 3.5f;
    public float laneSnapSpeed = 5f;
    public float driftAngle = 15f;
    public float driftSnapSpeed = 5f;
    public float reverseSpeedMultiplier = 0.5f;

    [Header("Speed Boost Settings")]
    public float distanceStep = 100f;     // Increase speed every 100 units
    public float speedIncrement = 2f;     // How much to increase
    public float maxSpeed = 30f;          // Optional cap

    private Rigidbody rb;
    private int currentLane = 0;          // -1 = left, 0 = center, 1 = right
    private float targetRotationZ = 0f;
    private bool isStopped = false;
    private float laneXVelocity = 0f;
    private float fixedY = 0.5f;
    private float nextSpeedBoostZ = 100f;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            Debug.LogError("Rigidbody missing on " + gameObject.name);
            enabled = false;
            return;
        }
    }

    void Update()
    {
        HandleInput();
    }

    void FixedUpdate()
    {
        if (!isStopped)
        {
            // Calculate target X based on lane
            float targetX = currentLane * laneWidth;
            float newX = Mathf.SmoothDamp(rb.position.x, targetX, ref laneXVelocity, 1f / laneSnapSpeed);

            // Move forward along Z
            float newZ = rb.position.z + forwardSpeed * Time.fixedDeltaTime;

            // 🚀 Distance-based speed boost
            if (newZ >= nextSpeedBoostZ)
            {
                forwardSpeed = Mathf.Min(forwardSpeed + speedIncrement, maxSpeed);
                nextSpeedBoostZ += distanceStep;
                Debug.Log("Speed increased to: " + forwardSpeed);
            }

            // Apply new position
            Vector3 targetPosition = new Vector3(newX, fixedY, newZ);
            rb.MovePosition(targetPosition);

            // Smooth drift rotation
            float currentZ = transform.rotation.eulerAngles.z;
            float smoothZ = Mathf.LerpAngle(currentZ, targetRotationZ, Time.fixedDeltaTime * driftSnapSpeed);
            transform.rotation = Quaternion.Euler(0, 0, smoothZ);
        }
    }

    void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
            MoveLeft();
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
            MoveRight();

        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
            ReverseCar();

        if (Input.GetKeyDown(KeyCode.Space))
            isStopped = !isStopped;

        // Reset drift smoothly when no horizontal key is pressed
        if (!Input.GetKey(KeyCode.LeftArrow) && !Input.GetKey(KeyCode.RightArrow) &&
            !Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D))
            targetRotationZ = 0f;
    }

    public void ReverseCar()
    {
        Vector3 reverseMove = -transform.forward * forwardSpeed * reverseSpeedMultiplier * Time.fixedDeltaTime;
        rb.MovePosition(rb.position + reverseMove);
    }

    public void MoveLeft()
    {
        if (currentLane > -1)
        {
            currentLane--;
            targetRotationZ = driftAngle; // tilt left
        }
    }

    public void MoveRight()
    {
        if (currentLane < 1)
        {
            currentLane++;
            targetRotationZ = -driftAngle; // tilt right
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("coin"))
        {
            ScoreManager sm = FindObjectOfType<ScoreManager>();
            if (sm != null)
            {
                sm.AddCoin(); // ✅ Increase coin count
            }

            Destroy(other.gameObject); // Remove coin
        }
    }
}