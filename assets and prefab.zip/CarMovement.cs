using UnityEngine;
using UnityEngine.SceneManagement;

public class CarMovement : MonoBehaviour
{
    public float speed = 30f;

    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }

    public class CarCollisionHandler : MonoBehaviour
    {
        void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.CompareTag("SpawnedCar"))
            {
                Debug.Log("Collision Detected with Spawned Car!");
                StopGame();
            }
        }

        void StopGame()
        {
            Time.timeScale = 0f; // Pauses the game
                                 // Optional: Show Game Over UI or restart
                                 // SceneManager.LoadScene(SceneManager.GetActiveScene().name); // To restart
        }
    }
}
