﻿using UnityEngine;

public class Coin : MonoBehaviour
{

    [Header("Coin Settings")]
    public int coinValue = 10; // value per coin
   
   


    void Update()
    {
        // Optional: rotate the coin for animation
        transform.Rotate(0f, 100f * Time.deltaTime, 0f);
    }
    
}
