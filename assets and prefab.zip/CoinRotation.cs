using UnityEngine;

public class CoinRotation : MonoBehaviour
{
    [SerializeField] float rotationSpeed = 200f; // degrees per second

   
    void Update()
    {
        Debug.Log("CoinRotator running");
        transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
    }
}