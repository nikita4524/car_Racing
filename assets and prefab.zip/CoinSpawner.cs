﻿using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
   public GameObject coinPrefab;
}
