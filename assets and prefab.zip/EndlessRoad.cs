﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndlessRoad : MonoBehaviour
{
    [Header("Player & Road Settings")]
    [SerializeField] private Transform playerCarTransform;
    [SerializeField] private EndlessRoad otherChunk; // Reference to the other city chunk
    [SerializeField] private float halfLength = 50f;
    [SerializeField] private float fixedY = 0f;

    [Header("Car Spawning")]
    [SerializeField] private GameObject[] carPrefabs;
    [SerializeField] private float carSpawnHeight = 0f;
    [SerializeField] private int numberOfLanes = 3;
    [SerializeField] private float laneWidth = 3f;
    [SerializeField] private float carSpawnZOffset = 10f;
    [SerializeField] private float carSpeedMin = 8f;
    [SerializeField] private float carSpeedMax = 15f;

    [Header("Coin Spawning")]
    [SerializeField] private GameObject[] coinPrefabs;
    [SerializeField] private int coinsToSpawnMin = 3;
    [SerializeField] private int coinsToSpawnMax = 6;
    [SerializeField] private float coinSpawnHeight = 0.5f;
    [SerializeField] private float coinLaneWidth = 3f;
    [SerializeField] private float coinSpawnZOffset = 10f;

    void Update()
    {
        // Move chunk forward when player passes it
        if (playerCarTransform.position.z > transform.position.z + halfLength)
        {
            MoveChunkForward();
        }
    }

    private void MoveChunkForward()
    {
        float newZ = otherChunk.transform.position.z + halfLength * 2;
        transform.position = new Vector3(0, fixedY, newZ);

        SpawnCarsOnChunk();
        SpawnCoinsOnChunk();
    }

    private void SpawnCarsOnChunk()
    {
        if (carPrefabs.Length == 0) return;

        int carsToSpawn = Random.Range(1, 3);

        for (int i = 0; i < carsToSpawn; i++)
        {
            int laneIndex = Random.Range(0, numberOfLanes);
            float laneX = (laneIndex - (numberOfLanes - 1) / 2f) * laneWidth;
            float zOffset = carSpawnZOffset + Random.Range(0f, 30f);

            Vector3 spawnPos = new Vector3(laneX, fixedY + carSpawnHeight, transform.position.z + zOffset);
            GameObject car = Instantiate(carPrefabs[Random.Range(0, carPrefabs.Length)], spawnPos, Quaternion.Euler(0, 180f, 0));

            CarMovement movement = car.GetComponent<CarMovement>();
            if (movement != null)
            {
                movement.speed = Random.Range(carSpeedMin, carSpeedMax);
            }

            Rigidbody rb = car.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = true;
                rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ | RigidbodyConstraints.FreezePositionY;
            }
        }
    }

    private void SpawnCoinsOnChunk()
    {
        if (coinPrefabs.Length == 0) return;

        int coinsToSpawn = Random.Range(coinsToSpawnMin, coinsToSpawnMax);

        for (int i = 0; i < coinsToSpawn; i++)
        {
            int laneIndex = Random.Range(0, numberOfLanes);
            float laneX = (laneIndex - (numberOfLanes - 1) / 2f) * coinLaneWidth;
            float zOffset = coinSpawnZOffset + Random.Range(0f, 40f);

            Vector3 spawnPos = new Vector3(laneX, fixedY + coinSpawnHeight, transform.position.z + zOffset);
            Quaternion coinRotation = Quaternion.Euler(0, 0, 90);

            Instantiate(coinPrefabs[Random.Range(0, coinPrefabs.Length)], spawnPos, coinRotation);
        }
    }
}