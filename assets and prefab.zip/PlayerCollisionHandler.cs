using UnityEngine;

public class PlayerCollisionHandler : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("SpawnedCar"))
        {
            Debug.Log("Hit a spawned car! Game Over.");
            Time.timeScale = 0f; // Stops the game
        }
    }
}
