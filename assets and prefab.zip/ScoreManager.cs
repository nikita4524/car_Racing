using System.Collections;
using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public int score = 0;
    public int coinsCollected = 0;

    public TextMeshProUGUI Scoretext;
    public TextMeshProUGUI CoinText;

    void Start()
    {
        StartCoroutine(ScoreRoutine());
    }

    IEnumerator ScoreRoutine()
    {
        while (true)
        {
            score += 1;
            UpdateScoreUI();
            yield return new WaitForSeconds(0.8f);
        }
    }

    public void AddCoin()
    {
        coinsCollected += 1;
        UpdateCoinUI();
        Debug.Log("Coins: " + coinsCollected);
    }

    void UpdateScoreUI()
    {
        if (Scoretext != null)
        {
            Scoretext.text = "Distance : " + score.ToString();
        }
    }

    void UpdateCoinUI()
    {
        if (CoinText != null)
        {
            CoinText.text = "Coins : " + coinsCollected.ToString();
        }
    }
}