using UnityEngine;
using UnityEngine.SceneManagement;

public class SwiftCarCollision : MonoBehaviour
{
    // Reference to the Game Over UI panel
    public GameObject gameOverPanel;

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("Collided with: " + collision.gameObject.name);

        // Check if the collided object has the tag "Enemy"
        if (collision.gameObject.CompareTag("enemy"))
        {
            Debug.Log("Game Over Triggered!");
            Time.timeScale = 0f;
            gameOverPanel.SetActive(true);
        }
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
