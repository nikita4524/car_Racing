﻿using UnityEngine;

public class CoinCollector : MonoBehaviour
{
    // Reference to the AudioSource that plays the coin sound
    public AudioSource coinSound;

    // Triggered when the player enters a trigger collider (like a coin)
    private void OnTriggerEnter(Collider other)
    {
        // Check if the collided object has the tag "Coin"
        if (other.CompareTag("Coin"))
        {
            // 🔊 Play the coin collection sound
            coinSound.Play();

            // 💰 Destroy the collected coin object
            Destroy(other.gameObject);
        }
    }
}
