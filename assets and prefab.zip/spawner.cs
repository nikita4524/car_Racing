﻿using System.Collections;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [Header("Car Settings")]
    public GameObject[] cars;                  // Array of car prefabs to spawn
    public float spawnHeight = 0.5f;           // Height above the road to prevent clipping
    public Vector3 rotationOffset = new Vector3(0f, 180f, 0f); // Adjust based on prefab orientation

    [Header("Spawn Timing")]
    public float minSpawnTime = 2f;
    public float maxSpawnTime = 5f;

    [Header("Car Speed")]
    public float minSpeed = 8f;
    public float maxSpeed = 15f;

    void Start()
    {
        StartCoroutine(SpawnCars());
    }

    IEnumerator SpawnCars()
    {
        while (true)
        {
            yield return new WaitForSeconds(Random.Range(minSpawnTime, maxSpawnTime));

            if (cars.Length > 0)
            {
                int randomIndex = Random.Range(0, cars.Length);

                Vector3 spawnPos = new Vector3(
                    transform.position.x,
                    transform.position.y + spawnHeight,
                    transform.position.z
                );

                Quaternion spawnRot = Quaternion.Euler(rotationOffset);

                GameObject spawnedCar = Instantiate(cars[randomIndex], spawnPos, spawnRot);

                // 👇 Add this line to tag the spawned car
                spawnedCar.tag = "Obstacle";

                // Set car speed if CarMovement script is present
                CarMovement carScript = spawnedCar.GetComponent<CarMovement>();
                if (carScript != null)
                {
                    carScript.speed = Random.Range(minSpeed, maxSpeed);
                }
            }
            else
            {
                Debug.LogWarning("No car prefabs assigned in Spawner!");
            }
        }
    }
}